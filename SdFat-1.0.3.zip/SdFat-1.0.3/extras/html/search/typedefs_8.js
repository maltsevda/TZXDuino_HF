var searchData=
[
  ['streamsize',['streamsize',['../classios__base.html#a82836e1d3cc603fba8f0b54d323a2dff',1,'ios_base']]]
];
